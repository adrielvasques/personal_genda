# Personal-Agenda
-Explanation

Personal Agenda written in Java. Using BufferReader/Writer for storing the data to a standard .txt file for long term usage.

-Java Libraries Used

*UTIL (for data structures)

*JAVAX.SWING (for GUI)

*IO (for data storage)
